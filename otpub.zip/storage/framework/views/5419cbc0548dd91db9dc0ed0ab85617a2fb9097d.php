<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="page-content--bge5">
            <div class="container">
                <div class="login-wrap">
                    <div class="login-content">
                        <div class="login-logo">
                            <a href="#">
                                <img src="<?php echo e(asset('assets/images/logo/logo.png')); ?>" alt="Roghini Minerva Engineers">
                            </a>
                        </div>
                        <div class="login-form">
                            <?php $errormsg = app('App\Http\Controllers\UserController'); ?>
                            <?php echo e($errormsg->displayAlert()); ?>

                            <form id="pass-update" action="<?php echo e(URL::to('/login')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label>Email Address</label>
                                    <input class="au-input au-input--full validate[required,custom[email]]" type="email" name="email" placeholder="Email">
                                </div>
                                <div class="form-group">
                                    <label>Password</label>
                                    <input class="au-input au-input--full validate[required]" type="password" name="password" placeholder="Password">
                                </div>
                                <div class="login-checkbox">
                                    <label>
                                        <input type="checkbox" name="remember">Remember Me
                                    </label>
                                    <label>
                                        <a href="<?php echo e(URL::to('/forgotpassword')); ?>">Forgotten Password?</a>
                                    </label>
                                </div>
                                <button class="au-btn au-btn--block au-btn--green m-b-20" type="submit">sign in</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('additional-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/validation-engine-master/css/validationEngine.jquery.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('additional-js'); ?>
    <script src="<?php echo e(asset('assets/vendor/validation-engine-master/js/languages/jquery.validationEngine-en.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/validation-engine-master/js/jquery.validationEngine.js')); ?>"></script>
    <script>
        $(document).ready(function () {
            $("#pass-update").validationEngine();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/apptex/resources/views/Login/login.blade.php ENDPATH**/ ?>