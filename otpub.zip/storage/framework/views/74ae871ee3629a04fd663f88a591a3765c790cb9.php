<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Fontfaces CSS-->
    <link href="<?php echo e(asset('assets/css/font-face.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('assets/vendor/font-awesome-4.7/css/font-awesome.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('assets/vendor/font-awesome-5/css/fontawesome-all.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('assets/vendor/mdi-font/css/material-design-iconic-font.min.css')); ?>" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="<?php echo e(asset('assets/vendor/bootstrap-4.1/bootstrap.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('assets/css/w3.css')); ?>" rel="stylesheet" media="all">
    <!-- Additional CSS-->
    <?php echo $__env->yieldContent('additional-css'); ?>

    <!-- Main CSS-->
    <link href="<?php echo e(asset('assets/css/theme.css')); ?>" rel="stylesheet" media="all">
</head>
<body>

    <?php echo $__env->yieldContent('content'); ?>
    <!-- Jquery JS-->
    
    <script src="<?php echo e(asset('assets/vendor/jquery-3.5.1.js')); ?>"></script>
    <!-- Bootstrap JS-->
    <script src="<?php echo e(asset('assets/vendor/bootstrap-4.1/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/bootstrap-4.1/bootstrap.min.js')); ?>"></script>

    <!-- Additional JS -->
    <?php echo $__env->yieldContent('additional-js'); ?>

    <!-- Main JS-->
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
</body>
<?php echo $__env->yieldContent('model-content'); ?>
</html>
<?php /**PATH /opt/lampp/htdocs/apptex/resources/views/layouts/layout.blade.php ENDPATH**/ ?>