<?php $__env->startSection('contents'); ?>




    





    <div class="row">

        
    </div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/apptex/resources/views/client/home.blade.php ENDPATH**/ ?>