<?php $__env->startSection('pagecontent'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('additional-js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/apptex/resources/views/dashboard/index.blade.php ENDPATH**/ ?>