<?php $__env->startSection('contents'); ?>

<section class="w3l-pricing1 py-5 mt-5">
    <div class="container py-lg-3 mt-3">
        <div class="heading text-center mx-auto">
            <h3 class="head">Thanks M/s <?php echo e($data['name']); ?> </h3>
            
        </div>
        <div class="row">
            
            <div class=" offset-4 col-md-4">
                <div class="mt-5 price-card price-card2 p-lg-4 p-md-3 p-4 recomemded-price">
                    <div class="card-header p-0 card-heading">
                        <h4 class="mb-4">Payment </h4>
                    </div>
                    <div class="card-body p-0">
                        <h1 class="card-title pricing-card-title my-price-title">₹ <?php echo e($data['amount']); ?><small class="text-dull">/month</small></h1>
                        <p>It is a long established fact that a reader will be distracted by the readable content.</p>
                        <ul class="list-unstyled list-pricing mt-3 mb-4">
                            <li>20 users included</li>
                            <li>10 GB of storage</li>
                            <li>Priority email support</li>
                            <li>Help center access</li>
                        </ul>
                        <div class="text-center mt-4">
                            <form action="<?php echo e(URL::to('paymentsuccess')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <script
                                    src="https://checkout.razorpay.com/v1/checkout.js"
                                    data-key="<?php echo e($data['key']); ?>"
                                    data-amount="<?php echo e($data['amount']); ?>"
                                    data-currency="INR"
                                    data-name="<?php echo e($data['name']); ?>"
                                    data-image="<?php echo e($data['image']); ?>"
                                    data-description="<?php echo e($data['description']); ?>"
                                    data-prefill.name="<?php echo e($data['prefill']['name']); ?>"
                                    data-prefill.email="<?php echo e($data['prefill']['email']); ?>"
                                    data-prefill.contact="<?php echo e($data['prefill']['contact']); ?>"
                                    data-notes.shopping_order_id="<?php echo e($data['notes']['merchant_order_id']); ?>"   
                                    data-order_id="<?php echo e($data['order_id']); ?>"                                       
                                    <?php if($displayCurrency!== 'INR'): ?>
                                    data-display_amount="<?php echo e($data['display_amount']); ?>"
                                    data-display_currency="<?php echo e($data['display_currency']); ?>"
                                    <?php endif; ?>

                                >
                                </script>
                                <!-- Any extra fields to be submitted with the form but not sent to Razorpay -->
                                <input type="hidden" name="shopping_order_id" value="<?php echo e($data['order_id']); ?>">
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/apptex/resources/views/client/payamount.blade.php ENDPATH**/ ?>