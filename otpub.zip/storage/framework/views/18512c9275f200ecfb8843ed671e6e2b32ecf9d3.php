<?php $__env->startSection('contents'); ?>




    





        <div class="row">
            <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cnt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-2">
                <section class="w3l-career1 py-3 mt-3">
                   <center>  <?php echo e($cnt->country_name); ?>

                <div class=" img-circle  d-md-block d-none">
                    <a href="<?php echo e(URL::to("catagory/".$cnt->id)); ?>">
                    <img src="<?php echo e(asset('assets/client/images/'.$cnt->icon_image )); ?>" class=" rounded" alt="<?php echo e($cnt->country_name); ?>" />



                    </a>
                </div>
                   </center>
                </section>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/apptex/resources/views/client/index.blade.php ENDPATH**/ ?>