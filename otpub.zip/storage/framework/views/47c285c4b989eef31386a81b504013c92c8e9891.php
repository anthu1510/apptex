<?php $__env->startSection('contents'); ?>

    <section class="w3l-pricing1 py-5 mt-5">
        <div class="container py-lg-3 mt-3">
            <div class="heading text-center mx-auto">
                <h3 class="head">Thanks M/s <?php echo e($supplier->name); ?> </h3>
                
            </div>
            <div class="row">
                
                <div class=" offset-4 col-md-4">
                    <div class="mt-5 price-card price-card2 p-lg-4 p-md-3 p-4 recomemded-price">
                        <div class="card-header p-0 card-heading">
                            <h4 class="mb-4">Status <span class="label label-paysuccess">Payment Success</span></h4>
                        </div>
                        <div class="card-body p-0">
                            <h1 class="card-title pricing-card-title my-price-title">₹ 1500<small class="text-dull">/month</small></h1>
                            <p>We recive the Payment</p>
                            <ul class="list-unstyled list-pricing mt-3 mb-4">
                                <li>Transaction No: <span style="font-weight: bold"> <?php echo e($razorpay_order_id); ?> </span></li>
                                <li>Start Date: <span style="font-weight: bold"> <?php echo e($start_date); ?> </span></li>
                                <li>Validity Date: <span style="font-weight: bold"> <?php echo e($validity_date); ?> </span></li>

                            </ul>
                            <div class="text-center mt-4">

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/apptex/resources/views/client/payment_success.blade.php ENDPATH**/ ?>